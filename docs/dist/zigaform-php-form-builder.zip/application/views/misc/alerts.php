    <div class="alert alert-<?php echo $resp; ?>">
        <button data-dismiss="alert" class="close" type="button">x</button>
    <?php echo $content; ?>
    </div>
    